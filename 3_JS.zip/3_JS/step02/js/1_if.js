/*
    ?조건문
    실수사용의 예
    1.로그인 후 아이디와 패스워드가 서버에 저장된 정보와 같은지 비교 후 같다면 승인, 아니라면 오류메세지
    2. 게임같은 경우 자신이 공격을 했을 때 상대방을 타격 했는지 여부를 판별
    3. 경품추첨시 유저가 뽑은 번호에 따라 경품 당첨 여부를 따질 수 있습니다.
    4. 삭제작업 수행시 사용자가 yes를 눌렀을 때와 no를 눌렀을 때 수행할지 말지를 결정할 수 있다.
    5. slide 같은 ui component의 좌,우 방향으로 최대치를 이동 하였는지 판별 할 수 있습니다.
*/
function anORpm(){
    var date = new Date();
    var hour = date.getHours();
 
    if(hour < 12){
        alert("오전입니다.");
    }
    else{
        alert("오후입니다.");
    }
}

//홀, 짝 판별
function oddOrEven(){
    var numb = prompt('숫자를 입력하세요', '홀 ,짝을 구분하세요');

    if(numb%2==0){
        alert("짝수입니다.");
    }else{
        alert("홀수입니다.");
    }
}

//숫자판별
function numbJudgment(){
    var numb= prompt('숫자를 입력하세요','양수음수상관없습니다.');

    if(numb > 0){
        alert("양수입니다.")
    }else if(numb < 0){
        alert("음수입니다.");
    }else if(numb == 0){
        alert("0입니다.")
    }else{
        alert("숫자가 아닙니다.")
    }
}

//예제 다음 세과목의 점수를 입력 받고 평균을 구한 후 수,우,미,양,가를 출력하세요
//평균이 100점이 넘으면 입력값이 잘못되었습니다.
//100~90점 사이 수
//90~80점 사이 우
//80~70점 사이 미
//70~60점 사이 양
//60점 이하 가

function avgScore(){
    var koreanScore = prompt("국어 점수 입력" ,'');
    var englishScore = prompt("영어 점수 입력", '');
    var mathScore = prompt("수학 점수 입력", '');
    var sum = parseInt(koreanScore) + parseInt(englishScore)+parseInt(mathScore);
    var avg= sum/3;
    alert("평균은 = "+ avg);

    if(avg > 100){
        alert('입력값이 잘못되었습니다.');
    }else if(avg< 100 && avg>=90){
        alert("수");
    }else if(avg<90 && avg >=80){
        alert("우");
    }else if(avg<80 && avg >=70){
        alert("미");
    }else if(avg<70 && avg >=60){
        alert("양");
    }else{
        alert("가");
    }
}

function login(){
    var id = prompt("아이디 입력");
    var password = prompt("비밀번호입력");
    host_id = 'asdf';
    host_pwd = 'qwer';
    if(id==host_id && password==host_pwd ){
        alert("로그인 되었습니다.");
    }else if(id==host_id && password!=host_pwd){
        alert('비밀번호가 틀렸습니다.');
    }else if(id!=host_id && password==host_pwd){
        alert('아이디가 틀렸습니다.');
    }else{
        alert('둘다 틀림.');
    }
}

function log(){
    var id = prompt("아이디 입력");
    host_id = 'asdf';
    if(id==host_id){
        alert('아이디가 맞습니다.')
    }else{
        alert('아이디가 틀렸습니다.')
    }
}

function web(){
    var language = prompt("언어를 입력하세요!", '');
    if(language == 'HTML' || language=='CSS' || language == 'JS'){
        alert(language+'!');
    }else{
        alert('올바를값을 입력하세요!');
    }
}
web();
