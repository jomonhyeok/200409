/*
    ?switch
    switch 딱딱 떨어지는 값의 조건을 비교할 때 사용합니다.
    (< . > , <=, >=, !=와 같은 연산자를 사용안했을 경우에만)
*/
function lotto(){
    var numbValue = window.prompt("입력번호?");

    switch(numbValue){
        case "1":
            alert("1등 1억");
            break;
        case "2":
            alert("2등 5천만원");
            break;
        case "3":
            alert("3등 400만원");
            break;
        default:
            alert("낙첨");
            break;
    }
}

function oddOrEven(){
    var num =window.prompt("입력번호?");
    var result = num%2;
    switch(result){
        case 0:
            alert("짝수");
            break;
        case 1:
            alert("홀수");
            break;
    }
}

function calculator(){
    var firstNumb =window.prompt("첫번째번호입력?");
    var lastNumb =window.prompt("두번째번호입력?");
    var operator =window.prompt("연산자입력?");
    
    switch(operator){
        case "+":
            alert(parseInt(firstNumb)+parseInt(lastNumb));
            break;
        case "-":
            alert(parseInt(firstNumb)-parseInt(lastNumb));
            break;
        case "*":
            alert(parseInt(firstNumb)*parseInt(lastNumb));
            break;
        case "/":
            alert(parseInt(firstNumb)/parseInt(lastNumb));
            break;
        default:
            alert("연산자를 잘못입력했습니다.");
            break;
    }
}