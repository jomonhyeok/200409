/*
    ? 반복문 for

    *루프
    1. 초기식 실행>
    2. 조건식 비교, 조건이 거짓일 경우 반복문 종료>
    3. 참일경우 문장 실행>
    4. 종결식 실행 > 
    5. 2단계
 */

// !단일 for
function namePrint01(){
    var userName = "CHO";
    for(var i=1 ; i<10 ; i++){
        document.write(i + "." + userName + "<br>");
    }
}

function namePrint1000(){
    var userName = "CHO";
    for(var i=1 ; i<=1000; i++){
        document.write(i+ '.' + userName + "<br>");
    }
}

function namePrint500(){ //홀수출력
    var userName = "CHO";
    for(var i=1 ; i<=1000 ; i+=2){
        document.write(i+ '.' + userName + "<br>");
    }
}

function answer1(){
    for(var i=0; i<10; i++){
        document.write((i+1)+ "<br>");
    }
}

function thinkJS(){
    for(var i=0; i<10; i++){
        document.write(i+ "<br>");
    }
    document.write("실행횟수"+i);
}

function answer2(){
    for(var i=1; i<=10;i++){
        document.write(i + "<br>");
    }
}

function answer3(){
    for(var i=100; i<=110;i++){
        document.write(i + "<br>");
    }
}

function answer4(){
    for(var i=1; i<=10; i+=2){
        document.write(i + "<br>" + (i+1) + "<br>");
    }
}

function answer5(){
    for(var i=10; i>=1; i--){
        document.write(i + "<br>");
    }
}

function answer6(){
    for(var i=1;i<=10;i++){
        document.write("*");
    }
}

function answer7(){
    for(var i=1;i<=10;i++){
        for(var j=10;j>=1;j--){
            document.write("*");
        }
        document.write("<br>");
    }
}
answer7();

function favor(){
    var array = ["이은혜","서지양", "전세영","조민혁","김태희"];
    // console.log(array.length);
    // console.log(array[0]);
    for(var i=0; i<array.length; i++){
        alert(array[i]);
    }
}

function reverseFavor(){
    var array = ["이은혜","서지양", "전세영","조민혁","김태희"];
    for(var i=array.length-1; i>0; i--){
        alert(array[i]);
    }
}




